[center][color=red][size=16pt][b]KeyCAPTCHA for SMF[/b][/size][/color]
[size=14pt][color=orange]v.2.5[/color][/size] 
[color=green][b][size=12pt]Автор модификации: [url=http://www.simplemachines.ru/index.php?action=profile;u=9483]0daliska[/url][/size][/b][/color]
[color=blue][b][size=12pt]Автор исходного кода: [url=http://www.simplemachines.org/community/index.php?action=profile;u=273151]KeyCAPTCHA[/url][/size][/b][/color]
[color=blue][b][size=10pt]Совместимость: версии SMF 1.1.8 - 1.1.16, SMF 2.0 RC3 - RC5 и SMF 2.0 - 2.0.4[/size][/b][/color]
[/center]
[hr]
[size=13pt][color=maroon][u][b]Описание[/b][/u][/color][/size]
[center]KeyCAPTCHA поддерживает два режима работы: Flash и HTML5. При загрузке KeyCAPTCHA автоматически определяет режим своей работы в веб-браузере посетителя.[/center]

[center]Интерактивность нашей капчи заключается в том, что посетителю Вашего сайта предлагается восстановить объекты в соответствии с заданием, а не угадать ее содержание, как в других капчах.[/center]

[center]Более подробную информацию Вы можете получить на сайте: [url=https://www.keycaptcha.com/]https://www.keycaptcha.com/[/url][/center]
[hr]
[size=13pt][color=maroon][u][b]Особенности[/b][/u][/color][/size]

[list]
[li]За случайную расстановку неподвижных объектов отвечает сервер KeyCAPTCHA. Таким образом, спам-боты не могут найти их координаты в исходном коде страницы. [/li]
[li]Проверка корректности выполнения задания происходит на сервере KeyCAPTCHA. Соответственно, на странице, защищенной KeyCAPTCHA, полностью отсутствует информация о правильном ответе. По этой причине спам-боты не имеют возможности узнать правильный ответ.[/li]
[li]Вся передача данных между Вашим веб-сервером, веб-браузером посетителя и сервером KeyCAPTCHA защищается цифровой подписью. [/li]
[li]Ключи для проверки подлинности переданных данных хранятся только на сервере KeyCAPTCHA и в приватной части Вашего веб-сервера. Для большей степени защиты ключи уникальны для каждого сайта и имеют переменную длину 112-165 бит. Все это позволяет с уверенностью утверждать, что спам-боты полностью лишены возможности подделать передаваемые данные. [/li]
[/list]
[hr]
[size=13pt][color=maroon][u][b]Как использовать[/b][/u][/color][/size]
----------
Настройки для KeyCAPTCHA доступны:

[color=blue][b][size=12pt]SMF 1.1:[/size][/b][/color]
Администрирование -> Регистрация -> Настройки

[color=blue][b][size=12pt]SMF 2.0:[/size][/b][/color]
Админ -> Безопасность и модерирование -> Анти-спам

[color=red][size=16pt]Установка приватного ключа является обязательной для использования KeyCAPTCHA. Вы должны зарегистрироваться на сервисе KeyCAPTCHA, чтобы получить свой персональный ключ.[/size][/color]

[color=#572500][b]Installation[/b][/color]
Любые предыдущие версии мода [b]ДОЛЖНЫ[/b] быть удалены [b]ДО[/b] установки текущей версии.

[hr]
[b]История версий:[/b]

Версия 1.0 - ноябрь, 2010 
поддержка только SMF 1.1.x

Версия 2.0 - март, 2011
+ добавлена поддержка SMF2.0 RC3 - RC5
+ добавлены комментарии в область настройки для smf1.1.x
o Обновление keycaptcha_class до версии v3.4.0

Версия 2.1 - июнь, 2011
+ добавлена поддержка SMF2.0 Gold

Версия 2.2 - июнь, 2011
! Исправлена ошибка загрузки капчи в личных сообщениях для SMF1.1.X 

Версия 2.3 - январь, 2012
+ добавлена поддержка SMF 2.0.2

Версия 2.4 - декабрь, 2012
+ добавлена поддержка SMF 2.0.3

Версия 2.5 - февраль, 2013
+ добавлена поддержка SMF 2.0.4

[hr]
[b]Лицензия[/b]
-------
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License version 2 as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
[hr]
[size=13pt][color=maroon][u][b]Acknowledgements[/b][/u][/color][/size]
----------------
"SMF" and "Simple Machines" are trademarks of Simple Machines LLC. 

Mersane, Ltd (c) 2011-2013
