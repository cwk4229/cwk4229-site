<?php
echo (gmdate("Y/m/d H:i:s",time()));
?>
