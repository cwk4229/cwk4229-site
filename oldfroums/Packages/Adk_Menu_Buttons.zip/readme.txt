[center][size=18pt][font=tahoma][b][color=#006666]Adk Menu Buttons[/color][/b][/font][/size][/center]

[center][url=http://www.smfpersonal.net/][img]http://www.smfpersonal.net/Adkmods/logo.png[/img][/url][/center]

[img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Autores/Authors:[/b]
     [url=http://www.smfpersonal.net/profiles/heracles-u259.html][color=#9A0ABC][b]^HeRaCLeS^[/b][/color][/url]
     [url=http://www.smfpersonal.net/profiles/enik-u417.html][color=#9A0ABC][b]enik[/b][/color][/url]
     
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Caracter�sticas:[/b]

Este mod permite activar desde la administraci�n una barra de botones extra.
Opciones:
		Activar/Desactivar el menu extra
		Activar/Desactivar botones (1 a 6)
		Ponerle nombre a los botones.
		Ingresar el link del los botones.
		Alinear los botones a la derecha.

Las opciones de este mod se encuentran en:
[i]Admin -> Modificaciones[/i]

Copyright 2011 by SMF Personal @ visita [url=http://www.smfpersonal.net]www.smfpersonal.net[/url] para soporte oficial. 

Si tu quieres ayudarnos,por favor visita nuestra seccion de contribuciones: [url=http://www.smfpersonal.net/about.html;sa=contritube-spanish]Contribuir[/url]

[hr]
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Features:[/b]

This mod allows enable from the administration an extra toolbar.
Options:
		Enable/disable the extra menu
		Enable/disable buttons (1 to 6)
		Write name buttons.
		Write link of the buttons.
		Align the buttons to the right.

The options of this mod are in:
[i]Admin -> Modification Settings[/i]

Copyright 2011 by SMF Personal @ visit [url=http://www.smfpersonal.net]www.smfpersonal.net[/url] for official support. 

If you want help, please visit our contributions section: [url=http://www.smfpersonal.net/about.html;sa=contribute]Contribute[/url]

[hr]

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Idiomas/Languages:[/b]
     [b]o[/b] English
     [b]o[/b] English-utf8
     [b]o[/b] Spanish_es
     [b]o[/b] Spanish_es-utf8
     [b]o[/b] Spanish_latin
     [b]o[/b] Spanish_latin-utf8
     [b]o[/b] portuguese_Pt
     [b]o[/b] portuguese_Pt-utf8
     [b]o[/b] portuguese_brazilian
     [b]o[/b] portuguese_brazilian-utf8
     [b]o[/b] persian
     [b]o[/b] persian-utf8

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Compatibilidad/Compatibility:[/b]
     [b]o[/b] SMF 2.0 Gold
     [b]o[/b] SMF 2.0.1
     [b]o[/b] SMF 2.0.2

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Desarrollador/Developer:[/b]
     [url=http://www.smfpersonal.net][b]Adk-Team[/b][/url]

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Traducciones/Translations:[/b]
     [b]o[/b] portuguese --> [url=http://www.simplemachines.org/community/index.php?action=profile;u=79248][b]Joomlamz[/b][/url]
     [b]o[/b] persian -----> [url=http://www.simplemachines.org/community/index.php?action=profile;u=255886][b]mrtarkhan[/b][/url]

