<?php

global $boardurl;

$txt = array();
$txt['bar_setings'] = 'Chat Bar Settings';
$txt['bar_social'] = 'Social';
$txt['bar_links'] = 'Links';
$txt['bar_gadgets'] = 'Gadgets';
$txt['home'] = 'Home';
$txt['msgs'] = 'Messages';
$txt['myspace'] = 'MySpace';
$txt['myspace1'] = 'Share on Myspace';
$txt['twitter'] = 'Tweet';
$txt['twitter1'] = 'Share on Twitter';
$txt['facebook'] = 'Facebook';
$txt['facebook1'] = 'Share on Facebook';
$txt['gplus'] = 'Google+';
$txt['gplus1'] = 'Share on Google+';
$txt['bil'] = 'Buddies/Ignore List';
$txt['addthis'] = 'Add This';
$txt['whos_on'] = 'Who&#39;s Online';
$txt['guest_msg'] = 'Welcome, Guest. Please <a class="white" href="'.$boardurl.'/index.php?action=login">login</a> or <a class="white" href="'.$boardurl.'/index.php?action=register">register.</a>';
$txt['load_warning'] = 'The chat is not availible due to high server load.';
?>