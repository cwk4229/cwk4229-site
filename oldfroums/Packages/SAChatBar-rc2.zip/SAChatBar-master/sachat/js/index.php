<?php
die('Hacking Attempt');
?>