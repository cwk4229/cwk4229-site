[b]NChat[/b] by [b]http://ThisMod.com[/b]

[u][b][color=red]NOTE[/color][/b][/u]
+ CHMOD 0666 for these files: l.txt, NChatMess.php, NChatMuteList.php
+ CHMOD 0644 for all the files left
+ CHMOD 0755 for these folders: ./NChat, ./NChat/sounds

[b][color=red]Nedd help?[/color][/b] [url=http://thismod.com/community/index.php?topic=3.0]Read this first![/url]

[b]Live demo[/b]: [url=http://thismod.com/community/index.php]ThisMod Community[/url]

[b]Update 1.3[/b]
+ Fix some bugs. [url=http://thismod.com/community/index.php?topic=2.0]Detail...[/url]
	- Error with "No sound" mode on IE.
	- NChat alwyas not available.
	
[b]Update 1.3[/b]
+ Adding many features. [url=http://thismod.com/community/index.php?topic=2.0]Detail...[/url]
  - Play a sound when new message comming.
  - Mute, disallow some one from chat (still not work for Guest).
  - Color + Clickable for user name.
+ Change and Optimize. [url=http://thismod.com/community/index.php?topic=2.0]Detail...[/url]
  - Move the Control Panel to AdminCP >> Modification Settings >> NChat Shoutbox.
  - Move the chat room to example.com/smf/NChat/index.php?acton=room
  - Reduced the time load, BW.
  - SMF smiles list now showing when enabled.
+ Fix some bugs. [url=http://thismod.com/community/index.php?topic=2.0]Detail...[/url]
  - Scroll issue when reading.
  - Error when switching smiles.
  - Fixed permission for Global Moderator.

[b]Future Developments:[/b]
+ Mute an IP.
+ Archive function.
+ Channel chat (private chat with one person).

[b]Donation[/b]
+ [url=https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=3BZAQJ5TDY27Y]Any donation will help the Mod better![/url]
