<?php die; ?>
a:0:{}