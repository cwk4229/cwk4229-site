<?php die; ?>
a:1:{i:0;s:118:"#ff00ff|!|#FF0000|!|1|!|ThisMod.com|!|Sep 07 19:42:34|!|Hi there! Delete this line and start your own chat, enjoy!|!|1";}